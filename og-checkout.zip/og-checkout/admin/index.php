<?php 
/** Silence is golden. */