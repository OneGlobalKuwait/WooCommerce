=== Og Checkout ===
Contributors: ogcheckout
Donate link: https://www.oneglobal.com/
Tags: og checkout, credit card
Requires at least: 3.0.1
Tested up to: 5.6
Requires PHP: 5.6
Stable tag: 3.2.9
Copyright: Payment Plugins
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Og Checkout makes it easy for your customers to pay online.

= Official One Global Partner = 
Payment Plugins is an official integration of One Global. 

= Visit our demo site to see all the payment methods in action = 
[Demo Site](https://ogbrains.com/plugins-demo/woocommerce/wp-admin)


== Frequently Asked Questions ==
= How do I test this plugin? = 
 You can enable the plugin's test mode, which allows you to simulate transactions.
 
= Does your plugin support WooCommerce Subscriptions? = 
No, currently the plugin doesn't supports any functionality related to WooCommerce Subscriptions.

= Where is your documentation? = 
https://checkoutdocs.oneglobal.com/

== Screenshots ==
1. Configuration page
2. Secure pay redirect on the checkout page
3. Custom Payment method modes

== Changelog ==
= 1.0.0 = 
* First commit

== Upgrade Notice ==
= 1.0.0 = 