# Ogpay Checkout WooCommerce Pluign

Introduction
Plugin Name : Ogpay Checkout
Item Version : v 1.0
Checkout Documentation Website: https://pay-it.mobi/payitcheckout/
WooCommerce Setup Documentation Website: https://pay-it.mobi/payitcheckout/Ogpay-woocommerce-online-documentation/

First of all, Thank you so much for using Ogpay Checkout Services.

Integrating your WooCommerce site with Og Pay checkout services allows you to accept payments on your WooCommerce site with simple installation. You can accept payments via debit card, credit card, & ATM Card. The plugin offers seamless integration, allowing the customer to pay on your website with high secure PCI compliance hosted environment and work across all browsers and ensures compatibility with the latest version of WooCommerce.

Compatibilities and Dependencies
Wordpress v3.9.2 or higher
Woocommerce v2.6 or higher
PHP v5.6.0 or higher

Note: The plugin has been tested upto WooCommerce v3.6.

Installation:
There are two methods to install the Ogpay WooCommerce plugin:
  
Method 1. Install via WordPress plugin Installer
Method 2. Install Plugins Manually through FTP

Caution: Always keep backup of your existing WooCommerce installation including Mysql Database, before installing a new module.

Method 1: Install via WordPress plugin Installer
Just simple steps to follow:
1. Login to WordPress Admin panel and goto Add New Plugin. Then click on Upload Plugin.
2. Choose this downloaded zip and click Install Now.

Method 2: Install Plugins Manually through FTP
1. Unzip and copy ‘Ogpay’ folder from this zip and upload to /wp-content/plugins folder.

Plugin Activation:
- Login to WP admin and goto Plugins
- Activate Plugin

Configuration:
Step 1: Go to Plugin Setting
Step 2: Tick to enable the module and Enter your Merchant ID & required Keys

Output: Go to Checkout Page

Support:
If you have any questions that are beyond the scope of this help file, please feel free email us at moin528@gmail.com
