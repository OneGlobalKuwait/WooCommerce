<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              www.oneglobal.com
 * @since             1.0.0
 * @package           Ogcheckout
 *
 * @wordpress-plugin
 * Plugin Name:       Og Checkout
 * Plugin URI:        www.oneglobal.com
 * Description:       Og Checkout makes it easy for your customers to pay online.
 * Version:           1.0.0
 * Author:            Oneglobal
 * Author URI:        www.oneglobal.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       ogcheckout
 * Domain Path:       
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'OGCHECKOUT_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-ogcheckout-activator.php
 */
function activate_ogcheckout() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-ogcheckout-activator.php';
	Ogcheckout_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-ogcheckout-deactivator.php
 */
function deactivate_ogcheckout() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-ogcheckout-deactivator.php';
	Ogcheckout_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_ogcheckout' );
register_deactivation_hook( __FILE__, 'deactivate_ogcheckout' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-ogcheckout.php';

add_filter('plugin_action_links', 'ogcheckout_plugin_action_links', 10, 2);
function ogcheckout_plugin_action_links($links, $file) {
     static $this_plugin;
     if (!$this_plugin) { $this_plugin = plugin_basename(__FILE__);}
     if ($file == $this_plugin) {
                $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=wc-settings&tab=checkout&section=ogcheckout">Settings</a>';
                array_unshift($links, $settings_link);
      }
            return $links;
}

/*
 * This action hook registers our PHP class as a WooCommerce payment gateway
 */
add_filter( 'woocommerce_payment_gateways', 'ogchekout_add_gateway_class' );
function ogchekout_add_gateway_class( $gateways ) {
	$gateways[] = 'WC_Ocheckout_Gateway'; // your class name is here
	return $gateways;
}
 


add_action( 'plugins_loaded', 'ogcheckout_init_gateway_classes' );

	function ogcheckout_init_gateway_classes(){
	class WC_Ocheckout_Gateway extends WC_Payment_Gateway {

			/**
			 * Class constructor, more about it in Step 3
			 */
			public function __construct() {

				$this->id = 'ogcheckout';
				$this->icon = 'https://checkoutadmin.oneglobal.com/pgimages/ogcheckout.png'; 
				$this->has_fields = true; 
				$this->method_title = 'Og Checkout';
				$this->method_description = 'Og Checkout makes it easy for your customers to pay online.'; // will be displayed on the options page

				$this->supports = array(
					'products',
					'default_credit_card_form'
				);

				// Method with all the options fields
				$this->init_form_fields();

				// Load the settings.
				$this->init_settings();
				$this->title = 'Og Checkout';
				$this->description = 'You will be redirect to Og Checkout secure page';
				$this->enabled = $this->get_option( 'enabled' );
				// This action hook saves the settings
				add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
				add_action( 'woocommerce_api_' . $this->id , array( $this, 'ogcheckoutCallback' ) );

				add_action( 'wp_enqueue_scripts', array( $this, plugin_dir_url( __FILE__ ) . 'js/ogcheckout-admin.js' ) );

			}

			/**
			 * Plugin options, we deal with it in Step 3 too
			 */
			public function init_form_fields(){
				$this->form_fields = array(
					'enabled' => array(
						'title'       => 'Enable/Disable',
						'label'       => 'Enable Og Chekout Gateway',
						'type'        => 'checkbox',
						'description' => '',
						'default'     => 'no'
					),
					'merchantcode' => array(
						'title'       => 'Merchant Name',
						'type'        => 'text',
						'default'     => '',
						'desc_tip'    => true,
					),		
					'authkey' => array(
						'title'       => 'Auth Key',
						'type'        => 'text',
						'default'     => '',
						'desc_tip'    => true
					),	
					'secretkey' => array(
						'title'       => 'Secret Key',
						'type'        => 'text',
						'default'     => '',
						'desc_tip'    => true,
					),
					'endpoint' => array(
						'title'       => 'Endpoint Url',
						'type'        => 'text',
						'default'     => '',
						'desc_tip'    => true
					),
					'language' => array(
						'title'       => 'Language',
						'type'        => 'text',
						'default'     => 'en',
						'desc_tip'    => true,
					),
					'tunnel' => array(
						'title'       => 'Tunnel',
						'type'        => 'text',
						'default'     => '',
						'desc_tip'    => true,
					),		
					'paymentmethodmode' => array(
						'title'       => 'Payment Method',
						'label'       => 'Payment Method',
						'type'        => 'select',
						'placeholder' => 'Select Payment Mode',
						'class'       => array('input-select'),
						'options'     => array(''=> 'Select Payment Method Mode','customize'=>'Customize Your Payment Form','ogpayment' => 'Og Checkout Payment Form'),
						'required'    => true,
					),
					'ogpaymentmethod' => array(
						'title'       => 'Payment Method',
						'type'        => 'text',
						'description' => __('Refer to Documentation'),
						'default' => '',
						'desc_tip' => true,
					),
					'ogpaymentcurrency' => array(
						'title'       => 'Payment Currency',
						'type'        => 'text',
						'description' => __('Leave this field blank when you use "all" parameter in Payment Method'),
						'default' => '',
						'desc_tip' => true,
					),				
					
				);		
			}
	

		public function payment_fields() {
 
	// I will echo() the form, but you can close PHP tags and print it directly in HTML
	echo '<fieldset id="wc-' . esc_attr( $this->id ) . '-cc-form" class="wc-credit-card-form wc-payment-form" style="background:transparent;">';
    echo '<div class="ogdesc">You will be redirect to Og Checkout Secure page</div>';
    if( 'ogcheckout' === esc_attr( $this->id ) ){
        
		$all_gateways = WC()->payment_gateways->payment_gateways();
		$allowed_gateways = $all_gateways['ogcheckout'];
		$allowed_gateways = $allowed_gateways->settings;
	
		if($allowed_gateways['paymentmethodmode']=='customize'){
			echo '<div  class="customize_payment_box" style="padding:10px 0;">';	
			echo '<input type="hidden" name="payment_method_mode" value="custompaymentmethod" />';
            $all_methods = json_decode(get_option( 'customize_payment_data' ),true);
			$i=0;
			foreach($all_methods as $method){ if($i==0){ $chk="checked";}else{$chk="";}?>
			<div class="radio radio_payment">
	        <label>
	<input type="radio" name="ogcheckout-methods" value="<?=$method['code']; ?>" class="ogcheckout_methods" <?=$chk; ?> /><?=$method['name'];?>           </label>
			<span><img src="https://checkoutadmin.oneglobal.com/pgimages/<?=$method['code']; ?>.png" width="50px"></span></div>
			<?php $i++;}
			echo '</div>';	
		}else{
		    echo '<input type="hidden" name="payment_method_mode" value="ogpaymentmethod" />';
		}
    }
 
	echo '<div class="clear"></div></fieldset>';
 
}
		
			public function process_payment( $order_id ) {
				
				if(isset($_POST['payment_method_mode'])){
					
					global $woocommerce;
					$all_gateways = WC()->payment_gateways->payment_gateways();
					$allowed_gateways = $all_gateways['ogcheckout'];
					$settings = $allowed_gateways->settings;
					$merchantcode = $settings['merchantcode'];
					$secretkey = $settings['secretkey'];
					$authkey = $settings['authkey'];
					$endpoint = $settings['endpoint'];
					$mode = $settings['paymentmethodmode'];
					$ogpaymentmethod = $settings['ogpaymentmethod'];
					$ogpaymentcurrency = $settings['ogpaymentcurrency'];
					if(empty($settings['language'])){
						$language = 'en';
					}else{
						$language = $settings['language'];
					}		

					if($_POST['payment_method_mode']=='ogpaymentmethod' && $mode=='ogpayment'){
						$paymentMethodCode = $ogpaymentmethod;
						if(!empty($ogpaymentcurrency)){
							$paymentMethodCurrency = $ogpaymentcurrency;
						}else{
							$paymentMethodCurrency = get_woocommerce_currency();
						}
                         
						$response = $this->getRedirectUrl($paymentMethodCode,$paymentMethodCurrency,$order_id);
					}

					if($_POST['payment_method_mode']=='custompaymentmethod' && $mode=='customize'){
						$payment_channels = json_decode(get_option( 'customize_payment_data' ),true);
						$paymentCode = $_POST['ogcheckout-methods'];
							foreach($payment_channels as $key=>$channel){
								if($channel['code']==$paymentCode){
									$paymentMethodCurrency = $channel['currency'];
								}
							}

                        
						$response = $this->getRedirectUrl($paymentCode,$paymentMethodCurrency,$order_id);
					}	

					  if(isset($response['success'])){
						return array(
							'result'    => 'success',
							'redirect'  => $response['url']
						);
					  }else{
						 wc_add_notice( $response['errorMessgae'], 'error' );
						 $order->add_order_note( 'Error: '. $response['errorMessgae'] );			
						 return array(
							'result'    => 'error',
							 'redirect' => $this->get_return_url( $order )
						 ); 
						  
					  }
				}

			}	
			public function getRedirectUrl($paymentMethodCode,$paymentMethodCurrency,$order_id){
				global $woocommerce;

				$all_gateways = WC()->payment_gateways->payment_gateways();
				$allowed_gateways = $all_gateways['ogcheckout'];
				$settings = $allowed_gateways->settings;

				$merchantID = $settings['merchantcode'];
				$secretkey = $settings['secretkey'];
				$authKey = $settings['authkey'];
				$endpoint = $settings['endpoint'];
				$mode = $settings['paymentmethodmode'];
				$ogpaymentmethod = $settings['ogpaymentmethod'];
				$ogpaymentcurrency = $settings['ogpaymentcurrency'];
				$currency = get_woocommerce_currency();
				$callback = WC()-> api_request_url( 'ogcheckout' );
				if(empty($settings['language'])){
					$language = 'en';
				}else{
					$language = $settings['language'];
				}

			   if($mode=='customize'){
				   if($paymentMethodCurrency==$currency){
					   $doConvert = "N";
					   $sourceCurrency = "";
				   }else{
					   $doConvert = "Y";
					   $sourceCurrency = $currency;		   
				   }	       
			   }

			   if($mode=='ogpayment'){

				   if(strcasecmp($ogpaymentmethod,"all")==0){
					   $doConvert = "N";
					   $sourceCurrency = "";	
					   $paymentMethodCurrency = $currency;
				   }else{
					   if($paymentMethodCurrency==$currency){
						   $doConvert = "N";
						   $sourceCurrency = "";
					   }else{
						   $doConvert = "Y";
						   $sourceCurrency = $currency;		   
					   }	           
				   }

			   }


				$items = $woocommerce->cart->get_cart();
				$description = array();

				foreach ($items as $item => $values) {
					$_product =  wc_get_product( $values['data']->get_id()); 
					$description[] = $_product->get_title();
				}

				$description = implode(' | ',$description);

				$order = wc_get_order( $order_id );

				$order_data = $order->get_data();

				$ref=$this->generateRefrenceId($order_id); // set up a blank string

				$timestamp = date("y/m/d H:m:s t");
				$tunnel = '';
				$userReference = $this->generateUserRefrenceId($order_data['billing']['phone']);
				$amount = $order_data['total'];

				$datatocomputeHash = (float)$amount.$authKey.$paymentMethodCurrency.$merchantID.$paymentMethodCode.(int)$ref.$sourceCurrency.$timestamp.$tunnel.(int)$userReference;

				$hash = strtoupper(hash_hmac("sha256", $datatocomputeHash,$secretkey));	

					   $data = array(
						  'merchantCode' => $merchantID,
						  'authKey' => $authKey,
						  'currency' => $paymentMethodCurrency,
						  'pc'=> $paymentMethodCode,
						  'tunnel'=> $tunnel,
						  'amount'=> (float)$amount,
						  'doConvert'=> $doConvert,
						  'sourceCurrency'=> $sourceCurrency,
						  'description'=> $description,
						  'referenceID'=> (int)$ref,
						  'timeStamp'=> $timestamp,
						  'language'=> $language,
						  'callbackURL'=> $callback,
						  'hash'=> $hash,
						  'userReference'=> (int)$userReference,
						  'billingDetails'=> array(
								'fName'=> $order_data['billing']['first_name'],
								'lName'=> $order_data['billing']['last_name'],
								'mobile'=> $order_data['billing']['phone'],
								'email'=> $order_data['billing']['email'],
								'city'=> $order_data['billing']['city'],
								'pincode'=> $order_data['billing']['postcode'],
								'state'=> $order_data['billing']['state'],
								'address1'=> $order_data['billing']['address_1'],
								'address2'=> $order_data['billing']['address_1']
						  ),
					);	
					$request = json_encode($data,true);	
                    
					if (!$endpoint) {
						$curl = curl_init('https://ogcheckoutstage.oneglobal.com/OgPay/V1/api/GenToken/Validate');
					} else {
						$curl = curl_init($endpoint);
					}

						curl_setopt($curl, CURLOPT_POST, true);
						curl_setopt($curl, CURLOPT_POSTFIELDS, $request);            
						curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));			
						$ch = curl_exec($curl);
						curl_close($curl);

						$response = json_decode($ch,true);
						$returnParam = array();

						if($response['errorCode']=='0'){
							$trackid = get_post_meta($order_id, 'track_id');
							if($trackid){
								update_post_meta($order_id, 'track_id',$ref);
							}else{
								add_post_meta($order_id, 'track_id',$ref);
							}					
							$returnParam['success'] = 'Y';
							$returnParam['url'] = $response['result']['redirectURL'];  	
						}else{
							$returnParam['error'] = 'Y';
							$returnParam['errorMessgae'] = $response['errorMessgae'];              
						}	
						return $returnParam;			

			}

    public function generateRefrenceId($orderid){

        $digits_needed = 15;
        
        $orderid = time().$orderid;
        
        $length = strlen((int)$orderid);
		
        if($length<$digits_needed){
		
			$required = $digits_needed-$length;
			
			$id='';
			for ($i = 1; $i <= $required; $i++) {
				   $id .= 1;
			}
			
			$refrenceId = $id.$orderid;
		}else{
			$refrenceId = $id.$orderid;
		}
		
        return (int)$refrenceId;
    }
    public function generateUserRefrenceId($uref=""){

        $digits_needed = 10;
        $uref = preg_replace("/[^0-9]/", "", $uref);
        $length = strlen($uref);
		$id='';
        if($length<$digits_needed){
		
			$required = $digits_needed-$length;
			
			
			for ($i = 1; $i <= $required; $i++) {
				   $id .= 1;
			}
			
			$refrenceId = $id.$uref;
		}else{
			$refrenceId = $id.$uref;
		}
		
        return (int)$refrenceId;
    }	

		public function ogcheckoutCallback($order) { 
		global $woocommerce, $post;

		if (isset($_GET['trackid'])) {
			$response = $_GET;
		} else {
			$response = 0;
		}
		
        if($response){
			$trackid = $_GET['trackid'];
			$all_gateways = WC()->payment_gateways->payment_gateways();
			$allowed_gateways = $all_gateways['ogcheckout'];
			$settings = $allowed_gateways->settings;

			$merchantID = $settings['merchantcode'];
			$secretkey = $settings['secretkey'];
			$authKey = $settings['authkey'];
			$endpoint = $settings['endpoint'];
			$mode = $settings['paymentmethodmode'];
			$ogpaymentmethod = $settings['ogpaymentmethod'];
			$ogpaymentcurrency = $settings['ogpaymentcurrency'];
			$currency = get_woocommerce_currency();
			$order_id = $this->get_order_id('track_id', $trackid);
			
			$order = wc_get_order($order_id);		
			$order_info = $order->get_data();

		if ($order_info) {

            //Validate response data
			$secretkey = $settings['secretkey'];
			$hash = $response['Hash'];
			$outParams = "trackid=".$trackid."&result=".$response['result']."&refid=".$response['refid'];
			$outHash = strtoupper(hash_hmac("sha256", $outParams,$secretkey));

			if($hash==$outHash){
			   
			if (isset($response['result'])) {
			
				switch($response['result']) {
					case 'CAPTURED':

						$order->update_status( 'processing' ); // Processing
						
						  // this is important part for empty cart
						  $woocommerce->cart->empty_cart();
						  // Redirect to thank you page
						  $url = $this->get_return_url( $order );						
						break;
					case 'NOT CAPTURED':
						$order->update_status( 'cancelled' ); // Missing
						$url = wc_get_checkout_url();
						break;
					case 'DECLINED':
						$order->update_status( 'cancelled' ); // Denied
						$url = wc_get_checkout_url();
						break;
					case 'REJECTED':
						$order->update_status( 'cancelled' ); // Denied
						$url = wc_get_checkout_url();
						break;
					case 'BLOCKED':
						$order->update_status( 'cancelled' ); // Denied
						$url = wc_get_checkout_url();
						break;
				}
			
			} else {
				$order->update_status( 'pending' );
				$url = wc_get_checkout_url();
			}
			  
			$note = "Track Id: ".$trackid."\r\n Payment Status: ".$response['result'];
			$order->add_order_note($note);	
			  wp_redirect( $url );
			  exit;

			}else{
				$url = wc_get_checkout_url();
				wp_redirect( $url );
				exit;				
			}
		  }
	    }		
	   }	
	   public function get_order_id($key, $value) {
		   global $wpdb;
		   $meta = $wpdb->get_results("SELECT * FROM ".$wpdb->postmeta." WHERE meta_key='".$wpdb->escape($key)."' AND meta_value='".$wpdb->escape($value)."'");
		   if (is_array($meta) && !empty($meta) && isset($meta[0])) {
			     $meta = $meta[0];
			  }   
		   if (is_object($meta)) {
			    return $meta->post_id;
			  }
		   else {
			    return false;
			  }
		   }
		
	}
	}
/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_ogcheckout() {

	$plugin = new Ogcheckout();
	$plugin->run();

}
run_ogcheckout();
